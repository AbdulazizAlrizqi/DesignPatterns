
public class AudioAdapter implements AdvancedMediaPlayer{
	
	private AudioPlayer player;
	
	public AudioAdapter(AudioPlayer player){
		this.player = player;
	}

	@Override
	public void playVlc(String fileName) {
		
		System.out.println("vlc play" + fileName);
		player.toString();
		
	}

	@Override
	public void playMp4(String fileName) {
		
		System.out.println("palying mp4 name:" + fileName);
		player.toString();
		
	}

	
		
	
	

}

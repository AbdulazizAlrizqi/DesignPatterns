
public class BankAccountFacade {


	private int accountNumber;
	private int securityCode;
	AccountNumberCheck account;
	SecurityCodeCheck security;
	FundsCheck funds;
	WelcomeToBank Welcome;


	public BankAccountFacade(int newAcctNum, int newSecCode){
		accountNumber = newAcctNum;
		securityCode = newSecCode;
		Welcome = new WelcomeToBank();
		
		account = new AccountNumberCheck();
		security = new SecurityCodeCheck();
		funds = new FundsCheck();
		


	}

	public int getAccountNumber() { return accountNumber; }

	public int getSecurityCode() { return securityCode; }


	public void withdrawCash(double cashToGet){

		//check if account number is valid, account has available fund and security code is
		// correct, allow user to withdraw money and type "transaction complete" 
		// if not, type "transaction failed"
		
		if(account.accountActive(getAccountNumber()) && security.isCodeCorrect(getSecurityCode())&& funds.haveEnoughMoney(cashToGet)) {
			System.out.println("transaction complete");
		}else {
			System.out.println("transaction failed");
		}
	
		

	}


	public void depositCash(double cashToDeposit){

		//check if account number is correct and security code is correct, then allow user to
		// deposit money and type "transaction complete"
		// if not, type "transaction is not complete"
		
		if(account.accountActive(getAccountNumber()) && security.isCodeCorrect(getSecurityCode())) {
			funds.makeDeposit(cashToDeposit);
			System.out.println("transaction complete");
		}else {
			System.out.println("transaction is not complete");
		}
		


	}

}


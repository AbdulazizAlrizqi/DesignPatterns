
public class TestBankFacade {

	public static void main(String[] args){

		//type code to withdraw money and delete money using the facade class
		
		BankAccountFacade access = new BankAccountFacade(12345678,1234);
		
		access.withdrawCash(37.00);
		access.withdrawCash(2700);
		access.depositCash(600);
		

	}

}

